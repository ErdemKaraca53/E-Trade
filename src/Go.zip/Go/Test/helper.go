package Test

import (
	"database/sql"
	"log"
	"module/utils"

	_ "github.com/go-sql-driver/mysql"
)

type Test_product struct {
	Type_id  *int
	Model_id *int
	Color_id *int
	Price    *int
}

type Test_stocks struct {
	Quantity int
	Size     string
	Location string
}

func TestDbConn() (db *sql.DB) {

	dbDriver := "mysql"
	dbUser := "root"
	dbPass := "12345"
	dbName := "clone_etrade"
	db, err := sql.Open(dbDriver, dbUser+":"+dbPass+"@/"+dbName)
	if err != nil {
		panic(err.Error())
	}

	return db
}
func InsertLocations(db *sql.DB, Locations []utils.Locations) {
	str := "INSERT INTO locations (id, location, capacity, process) VALUES (?,?,?,?)"
	for _, loc := range Locations {
		_, err := db.Exec(str, loc.Id, loc.Location, loc.Capacity, loc.Process)
		if err != nil {
			log.Print(err.Error())
		}
	}
}

func InsertCargoInfos(db *sql.DB, cargoInfos []utils.CargoInfo) {
	str := "INSERT INTO orderpriceinfos (location_id, cargo_id, price_per_distance , discount_per_piece, order_price) VALUES (?,?,?,?,?)"
	for _, cargo := range cargoInfos {
		_, err := db.Exec(str, cargo.Location_id, cargo.Cargo_id, cargo.Price_per_distance, cargo.Discount_per_piece, cargo.Order_price)
		if err != nil {
			log.Print(err.Error())
		}
	}
}

func DeleteCargoInfos() {
	DeleteTable([]string{"orderpriceinfos"})
}

func DeleteLocations() {
	DeleteTable([]string{"locations"})
}
func InsertTypesTable(types string) (int, error) {

	db := TestDbConn()
	defer db.Close()

	var columns = []string{"type"}

	query := "INSERT INTO types ("
	for _, str := range columns {
		query += str
	}
	query += ") VALUES (?)"

	_, err := db.Exec(query, types)

	if err != nil {
		log.Print(err.Error())
	}

	var id int
	query = "SELECT id FROM types WHERE type=?"

	err = db.QueryRow(query, types).Scan(&id)

	if err != nil {
		log.Print(err.Error())
	}

	return id, err
}

func InsertBrandsTable(brand string) (int, error) {

	db := TestDbConn()
	defer db.Close()

	var columns = []string{"brand"}

	query := "INSERT INTO brands ("
	for _, str := range columns {
		query += str
	}
	query += ") VALUES (?)"

	_, _ = db.Exec(query, brand)

	var id int
	query = "SELECT id FROM brands WHERE brand=?"

	err := db.QueryRow(query, brand).Scan(&id)
	return id, err

}

func InsertModelsTable(brand string, model string) (int, error) {

	db := TestDbConn()
	defer db.Close()

	brand_id, _ := InsertBrandsTable(brand)
	var columns = []string{"brand_id,", "model"}

	query := "INSERT INTO models ("
	for _, str := range columns {
		query += str
	}
	query += ") VALUES (?, ?)"

	_, _ = db.Exec(query, brand_id, model)

	var id int
	query = "SELECT id FROM models WHERE brand_id=? AND model=?"

	err := db.QueryRow(query, brand_id, model).Scan(&id)
	return id, err
}

func InsertColorsTable(color string) (int, error) {

	db := TestDbConn()
	defer db.Close()

	var columns = []string{"color"}

	query := "INSERT INTO colors ("
	for _, str := range columns {
		query += str
	}
	query += ") VALUES (?)"

	_, _ = db.Exec(query, color)

	var id int
	query = "SELECT id FROM colors WHERE color=?"

	err := db.QueryRow(query, color).Scan(&id)

	return id, err
}

func InsertImagesTable(product_id int, image []string) error {

	db := TestDbConn()
	defer db.Close()

	var columns = []string{"product_id,", "image_url"}
	var err error

	for _, img := range image {

		query := "INSERT INTO images ("
		for _, str := range columns {
			query += str
		}
		query += ") VALUES (?, ?)"

		_, err = db.Exec(query, product_id, img)
		if err != nil {
			log.Print(err.Error())
		}

	}

	return err

}

func InsertProductsTable(product Test_product) (int, error) {

	db := TestDbConn()
	defer db.Close()

	var columns = []string{"type_id,", "model_id,", "color_id,", "price"}

	query := "INSERT INTO products ("
	for _, str := range columns {
		query += str
	}
	query += ") VALUES (?, ?, ?, ?)"

	_, _ = db.Exec(query, product.Type_id, product.Model_id, product.Color_id, product.Price)
	var product_id int

	query = "SELECT id FROM products WHERE type_id =? AND model_id =? AND color_id =? AND price =?"
	err := db.QueryRow(query, product.Type_id, product.Model_id, product.Color_id, product.Price).Scan(&product_id)
	return product_id, err

}

func DeleteTable(tableNames []string) {

	db := TestDbConn()

	for _, tableName := range tableNames {

		_, err := db.Exec("DELETE FROM " + tableName)

		if err != nil {
			log.Print(err.Error())
		}
	}

}

func DeleteProductsTable() {

	var tables = []string{"images", "products", "types", "models", "brands", "colors"}

	DeleteTable(tables)

}

func DeleteStockTable() {

	var tables = []string{"stocks", "sizes", "locations", "images", "products", "types", "models", "brands", "colors"}

	DeleteTable(tables)

}

func InsertSizesTable(size string) (int, error) {

	db := TestDbConn()
	defer db.Close()

	var columns = []string{"size"}

	query := "INSERT INTO sizes ("
	for _, str := range columns {
		query += str
	}
	query += ") VALUES (?)"

	_, _ = db.Exec(query, size)

	var id int
	query = "SELECT id FROM sizes WHERE size=?"

	err := db.QueryRow(query, size).Scan(&id)
	return id, err
}

func InsertLocationsTable(location string) (int, error) {

	db := TestDbConn()
	defer db.Close()

	var columns = []string{"location"}

	query := "INSERT INTO locations ("
	for _, str := range columns {
		query += str
	}
	query += ") VALUES (?)"

	_, _ = db.Exec(query, location)

	var id int
	query = "SELECT id FROM locations WHERE location=?"

	err := db.QueryRow(query, location).Scan(&id)

	return id, err
}

func InsertStocksTable(product_id int, quantity int, size_id int, location_id int) error {

	db := TestDbConn()
	defer db.Close()

	var columns = []string{"product_id,", "quantity,", "size_id,", "location_id"}

	query := "INSERT INTO stocks ("
	for _, str := range columns {
		query += str
	}
	query += ") VALUES (?, ?, ?, ?)"

	_, err := db.Exec(query, product_id, quantity, size_id, location_id)

	return err

}
